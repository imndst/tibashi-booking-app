// verify-dashboard.js
import { API_BASE_URL } from "./config.js";

export function initVerifyPhone(containerSelector, redirectQueryParam = "next") {
  const container = document.querySelector(containerSelector);
  const hasRedirect = new URLSearchParams(window.location.search)
    .get(redirectQueryParam)
    ?.startsWith("http");

  const requestOtpUrl = `${API_BASE_URL}/Auth/request-otp`;
  const verifyOtpUrl = `${API_BASE_URL}/Auth/verify-otp`;
  const meUrl = `${API_BASE_URL}/Auth/me`;
  const logoutUrl = `${API_BASE_URL}/Auth/logout`;
  const transactionsUrl = `${API_BASE_URL}/TransactionCheck/GetAllTransactions`;

  async function checkLogin() {
    const token = localStorage.getItem("jwt_token");
    const returnUrl = new URLSearchParams(window.location.search).get("returnUrl");

    if (returnUrl && token) return showReturnUrlModal(returnUrl, token);
    if (!token) return renderOtpForm();

    try {
      const res = await fetch(meUrl, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const user = await res.json();
        if (user?.name && user?.phone) renderDashboard(user, token);
        else renderOtpForm();
      } else renderOtpForm();
    } catch {
      renderOtpForm();
    }
  }

  // ===== Return URL Modal =====
  function showReturnUrlModal(returnUrl, token) {
    container.innerHTML = `
      <div class="return-modal" style="text-align:center;padding:30px;">
        <p>برای ادامه فرایند ثبت‌نام اینجا کلیک کنید</p>
        <button id="continueBtn" style="padding:10px 20px;background:#4CAF50;color:#fff;border:none;border-radius:6px;cursor:pointer;">ادامه</button>
      </div>
    `;
    container.querySelector("#continueBtn").addEventListener("click", async () => {
      if (!token) return renderOtpForm();
      try {
        const profileRes = await fetch(meUrl, { headers: { Authorization: `Bearer ${token}` } });
        const user = await profileRes.json();
        renderDashboard(user, token);
      } catch {
        renderOtpForm();
      }
    });
  }

  // ===== OTP FORM =====
  function renderOtpForm() {
    container.innerHTML = `
      <div class="verify-box">
        <h2>تأیید شماره تماس</h2>
        <form id="phoneForm">
          <input type="tel" id="phone" placeholder="شماره موبایل" required>
          <div class="form-row">
            <div class="toggle-group" id="genderToggle">
              <div class="toggle-option" data-value="male">آقا</div>
              <div class="toggle-option" data-value="female">خانم</div>
            </div>
            <div class="toggle-group" id="idTypeToggle">
              <div class="toggle-option selected" data-value="national">کد ملی</div>
              <div class="toggle-option" data-value="foreigner">کد اتباع</div>
            </div>
          </div>
          <input type="text" id="fullName" placeholder="نام و نام خانوادگی" required>
          <input type="text" id="nationalCode" placeholder="کد ملی" required>
          <button type="submit" class="btn-primary">دریافت کد پیامکی</button>
        </form>

        <form id="otpForm" style="display:none;">
          <input type="number" id="otp" placeholder="کد پیامکی" required>
          <button type="submit" class="btn-primary">تأیید کد</button>
        </form>

        <p class="loading" id="loading" style="display:none;">⏳ در حال دریافت...</p>
        <p class="error" id="error"></p>
        <p class="success" id="success"></p>
      </div>
    `;

    const phoneForm = container.querySelector("#phoneForm");
    const otpForm = container.querySelector("#otpForm");
    const phoneInput = container.querySelector("#phone");
    const otpInput = container.querySelector("#otp");
    const fullNameInput = container.querySelector("#fullName");
    const nationalCodeInput = container.querySelector("#nationalCode");
    const errorEl = container.querySelector("#error");
    const successEl = container.querySelector("#success");
    const loadingEl = container.querySelector("#loading");

    // Toggles
    const genderOptions = container.querySelectorAll("#genderToggle .toggle-option");
    const idTypeOptions = container.querySelectorAll("#idTypeToggle .toggle-option");

    let selectedGender = null;
    let selectedIdType = "national";

    genderOptions.forEach(opt => {
      opt.addEventListener("click", () => {
        genderOptions.forEach(o => o.classList.remove("selected"));
        opt.classList.add("selected");
        selectedGender = opt.dataset.value;
      });
    });

    idTypeOptions.forEach(opt => {
      opt.addEventListener("click", () => {
        idTypeOptions.forEach(o => o.classList.remove("selected"));
        opt.classList.add("selected");
        selectedIdType = opt.dataset.value;
        nationalCodeInput.placeholder = selectedIdType === "national" ? "کد ملی" : "کد اتباع";
      });
    });

    // Submit phone form
    phoneForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      errorEl.textContent = "";
      successEl.textContent = "";

      const phone = phoneInput.value.trim();
      const fullName = fullNameInput.value.trim();
      const nationalCode = nationalCodeInput.value.trim();

      if (!/^09\d{9}$/.test(phone)) {
        errorEl.textContent = "شماره موبایل معتبر وارد کنید.";
        return;
      }
      if (!selectedGender) {
        errorEl.textContent = "لطفاً جنسیت را انتخاب کنید.";
        return;
      }
      if (!fullName) {
        errorEl.textContent = "لطفاً نام و نام خانوادگی را وارد کنید.";
        return;
      }
      if (selectedIdType === "national") {
        if (!/^\d{10}$/.test(nationalCode) || !validateIranianNationalCode(nationalCode)) {
          errorEl.textContent = "کد ملی معتبر وارد کنید.";
          return;
        }
      } else {
        if (nationalCode.length < 5) {
          errorEl.textContent = "کد اتباع باید حداقل 5 رقم باشد.";
          return;
        }
      }

      const prefix = selectedGender === "male" ? "آقای" : "خانم";
      const fullNameWithPrefix = `${prefix} ${fullName}`;

      try {
        loadingEl.style.display = "block";
        const res = await fetch(requestOtpUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone, Name: fullNameWithPrefix, NationalCode: nationalCode }),
        });
        const data = await res.json();
        loadingEl.style.display = "none";

        if (data.status) {
          successEl.textContent = "✅ کد پیامکی برای شما ارسال شد!";
          phoneForm.style.display = "none";
          otpForm.style.display = "block";
        } else {
          errorEl.textContent = "❌ " + (data.message || "خطا در ارسال کد OTP");
        }
      } catch {
        loadingEl.style.display = "none";
        errorEl.textContent = "خطا در ارتباط با سرور.";
      }
    });

    // OTP form
    otpForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      errorEl.textContent = "";
      successEl.textContent = "";

      const phone = phoneInput.value.trim();
      const otp = otpInput.value.trim();
      if (!otp) {
        errorEl.textContent = "کد OTP را وارد کنید.";
        return;
      }

      try {
        loadingEl.style.display = "block";
        const res = await fetch(verifyOtpUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone, otp }),
        });
        const data = await res.json();
        loadingEl.style.display = "none";

        if (data.status && data.token) {
          localStorage.setItem("jwt_token", data.token);
          successEl.textContent = "✅ تأیید شد! در حال ورود به داشبورد...";
          setTimeout(async () => {
            const profileRes = await fetch(meUrl, { headers: { Authorization: `Bearer ${data.token}` } });
            const user = await profileRes.json();
            if (hasRedirect) user.redirectUrl = new URLSearchParams(window.location.search).get(redirectQueryParam);
            renderDashboard(user, data.token);
          }, 800);
        } else {
          errorEl.textContent = "❌ " + (data.message || "کد OTP اشتباه است.");
          otpInput.value = "";
        }
      } catch {
        loadingEl.style.display = "none";
        errorEl.textContent = "خطا در ارتباط با سرور.";
      }
    });
  }

  // ===== DASHBOARD =====
  async function renderDashboard(user, token) {
    container.innerHTML = `
      <div class="dashboard">
        <div class="header">
          <h2>خوش آمدید، <span id="displayName">${user.name}</span></h2>
         <div class="hamburger-menu">
  <span class="hamburger-icon">☰</span>
  <div class="menu-content">
    <a href="/" class="menu-link">🏠 خانه</a>
    <button id="logoutBtn" class="menu-btn">🚪 خروج</button>
  </div>
</div>

        </div>

        <div class="editable-field">
          <input id="nameInput" value="${user.name}" disabled>
          <button id="saveNameBtn" style="display:none;">💾</button>
        </div>

        <h3>تراکنش‌های موفق شما:</h3>
        <ul id="transactionList"><li>در حال بارگذاری...</li></ul>
      </div>
    `;

    const nameInput = container.querySelector("#nameInput");
    const saveBtn = container.querySelector("#saveNameBtn");
    const displayName = container.querySelector("#displayName");

    saveBtn.addEventListener("click", () => {
      const newName = nameInput.value.trim();
      if (!newName) return;
      displayName.textContent = newName;
      nameInput.disabled = true;
      saveBtn.style.display = "none";
    });

    container.querySelector("#logoutBtn").addEventListener("click", () => {
      localStorage.removeItem("jwt_token");
      renderOtpForm();
    });

    // Hamburger toggle
    const hamburger = container.querySelector(".hamburger-menu");
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("open");
    });

    // Load transactions
    const transactionList = container.querySelector("#transactionList");
    try {
      const res = await fetch(transactionsUrl, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (data.status && data.result) {
        const successOnly = data.result.filter(t => t.status === "Success");
        transactionList.innerHTML = successOnly.length
          ? successOnly.map(t => `<li><a href="/ticket/?res=${t.tiket}" class="text-green" target="_blank">${t.prognName} - ${t.programDate} (Success)</a></li>`).join("")
          : "<li>تراکنشی وجود ندارد</li>";
      } else transactionList.innerHTML = "<li>تراکنشی وجود ندارد</li>";
    } catch {
      transactionList.innerHTML = "<li>خطا در بارگذاری تراکنش‌ها</li>";
    }
  }

  function validateIranianNationalCode(code) {
    if (!/^\d{10}$/.test(code)) return false;
    const check = parseInt(code[9]);
    const sum = [...code].slice(0, 9).reduce((acc, digit, i) => acc + parseInt(digit) * (10 - i), 0);
    return ((sum % 11 < 2 && check === sum % 11) || (sum % 11 >= 2 && check === 11 - (sum % 11)));
  }

  checkLogin();
}
