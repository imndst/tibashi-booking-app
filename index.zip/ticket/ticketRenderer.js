
const API_BASE = "https://bg-moslem.gishot.ir/api/TempSeat";
const API_BASE_T = "https://bg-moslem.gishot.ir/api";

const ticketsDiv = document.getElementById("tickets");
const downloadBtn = document.getElementById("downloadPDF");

async function buildSeatPlan(eventId) {
  const res = await fetch(`${API_BASE_T}/Seat/plan/${eventId}`);
  const data = await res.json();

  if (!data.status) {
    throw new Error(data.message || "Failed to fetch seat plan");
  }

  let globalId = 0;
  const plan = [];

  const rows = data.result || [];
  rows.forEach((row, rowIndex) => {
    const seatCount = parseInt(row.seat_in_rows || 0, 10);
    for (let i = 0; i < seatCount; i++) {
      globalId++;
      plan.push({
        globalId,
        rowNumber: row.row_title?.trim() || rowIndex + 1,
        seatNumber: i + 1,
      });
    }
  });

  return plan;
}

async function getSeatByGlobalId(eventId, globalSeatId) {
  if (!eventId || !globalSeatId) {
    throw new Error("Both eventId and globalSeatId are required");
  }

  const plan = await buildSeatPlan(eventId);
  return plan.find((s) => s.globalId === Number(globalSeatId)) || null;
}

// Fetch ticket data from API
async function fetchTicket(id) {
  try {
    const res = await fetch(`${API_BASE}/ticket/${id}`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    return res.json();
  } catch (err) {
    console.error("API fetch error:", err);
    return { status: false, message: "خطا در دریافت اطلاعات از سرور" };
  }
}

// Render tickets
export async function renderTickets(id) {
  ticketsDiv.innerHTML = "";
  if (!id) {
    ticketsDiv.innerHTML =
      "<p style='color:red'>❌ شماره پیگیری وارد نشده است.</p>";
    return;
  }

  const data = await fetchTicket(id);
  if (!data.status) {
    ticketsDiv.innerHTML = `<p style='color:red'>❌ ${data.message}</p>`;
    return;
  }

  try {
    const { customer, seats, hall_name, address, lat, event_time } =
      data.result;

    new Date(customer.eventTime);

    // Convert dynamic time to Persian date/time
    const persianDate = new Intl.DateTimeFormat("fa-IR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "long",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date(event_time));

    if (!Array.isArray(seats) || seats.length === 0) {
      ticketsDiv.innerHTML =
        "<p style='color:red'>❌ هیچ صندلی برای این شماره پیگیری یافت نشد.</p>";
      return;
    }

    for (const seat of seats) {
      let seatInfo = null;
      try {
        seatInfo = await getSeatByGlobalId(customer.prId, seat.place);
      } catch (err) {
        console.warn("Seat info not found", err);
      }

      const ticket = document.createElement("div");
      ticket.className = "ticket";

      ticket.innerHTML = `
                <div class="ticket-header">
                    <div class="sponsor">Sponsor Tibashi-Gishot</div>
                </div>
                <h2>${customer.prognName || "رویداد"}</h2>
                <h1>${persianDate}</h1>
                <h3><strong>مشتری:</strong> ${customer.name || "-"}</h3>
                <p><strong>کد خریدار:</strong> ${customer.id || "-"}</p>
                <p><strong>تاریخ خرید:</strong> ${
                  customer.timeG
                    ? new Date(customer.timeG).toLocaleString("fa-IR")
                    : "-"
                }</p>
                <p><strong>ردیف:</strong> ${
                  seatInfo?.rowNumber || "-"
                } | <strong>صندلی:</strong> ${
        seatInfo?.seatNumber || seat.place
      }</p>
                <p><strong>قیمت:</strong> ${seat.much || "-"}</p>
                <div class="section">
                    <p><strong>محل رویداد:</strong> ${hall_name || "-"}</p>
                    <p><strong>آدرس:</strong> ${address || "-"}</p>
                    <p><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      address
                    )}" target="_blank">نمایش مسیر</a></p>
                </div>
                <div class="qr-barcode">
                    <canvas class="qrcode"></canvas>
                    <svg class="barcode"></svg>
                </div>
                <div class="footer">gishot.ir</div>
            `;

      ticketsDiv.appendChild(ticket);

      // Generate QR code
      try {
        QRCode.toCanvas(ticket.querySelector(".qrcode"), `${seat.barcode}`, {
          width: 100,
        });
      } catch (err) {
        console.warn("QR code error:", err);
      }

      // Generate barcode
      try {
        JsBarcode(ticket.querySelector(".barcode"), `${seat.barcode}`, {
          format: "CODE128",
          width: 2,
          height: 40,
        });
      } catch (err) {
        console.warn("Barcode error:", err);
      }
    }
  } catch (err) {
    console.error("Render error:", err);
    ticketsDiv.innerHTML = `<p style='color:red'>❌ خطا در نمایش بلیط‌ها</p>`;
  }
}

// PDF download
export function downloadTicketsPDF() {
  if (!ticketsDiv.innerHTML.trim()) {
    return alert("بلیتی برای دانلود وجود ندارد!");
  }

  try {
    html2pdf()
      .from(ticketsDiv)
      .set({
        margin: 0.5,
        filename: "tickets.pdf",
        html2canvas: { scale: 2 },
        pagebreak: { mode: "css", after: ".ticket" },
      })
      .save();
  } catch (err) {
    console.error("PDF download error:", err);
    alert("خطا در دانلود PDF");
  }
}
